from enum import Enum, auto


class Status(Enum):
    NULL = 'NULL'
    INPUT_MESSAGE = 'INPUT_MESSAGE'

    